#include "display.hpp"

// Display display{display_i2c_address, 16, 2};
